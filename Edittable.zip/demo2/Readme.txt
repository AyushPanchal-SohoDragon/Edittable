Author: Yogesh singh
Author URL: https://makitweb.com/
Author Email: yogesh@makitweb.com
Tutorial Link: https://makitweb.com/how-to-add-custom-filter-in-datatable-ajax-and-php/

Instructions - 
1. Import employee.sql table in your MySQL database.
2. Update config.php file.

